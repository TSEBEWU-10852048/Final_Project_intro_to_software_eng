		<div class="span3" id="sidebar">
	<center>

                    <ul class="nav nav-list bs-docs-sidenav nav-collapse collapse">
						<li><a href="dashboard.php"><i class="icon-chevron-left icon-large"></i><i class="icon-home icon-large"></i> Home</a></li>
						<li><a href="student_report.php"><i class="icon-chevron-right icon-large"></i><i class="icon-group icon-large"></i> Students Report</a></li>
						<li><a href="report_payment.php"><i class="icon-chevron-right icon-large"></i><i class="icon-money icon-large"></i>Payments Report</a></li>
						<li class="active"><a href="report_summary.php"><i class="icon-chevron-right icon-large"></i><i class="icon-table icon-large"></i> Payments Summary </a></li>
						<li><a href="activity_log.php"><i class="icon-chevron-right icon-large"></i><i class="icon-file icon-large"></i> Activity Log</a></li>
                    </ul>
	</center>
            </div>