<?php

$connection = mysqli_connect('localhost','root','','bilal');
if (!$connection) {
	die("Connection failed" . mysqli_connect_error());
}
?>
