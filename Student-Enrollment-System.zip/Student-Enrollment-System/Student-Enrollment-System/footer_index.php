<center>
		<footer>
           <p>All Rights Reserved </p>
        <footer>
</center>