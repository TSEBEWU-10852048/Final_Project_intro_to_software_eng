<center class="footer">
<hr>

		<footer>
           <p>All Rights Reserved  </p>
        <footer>
</center>