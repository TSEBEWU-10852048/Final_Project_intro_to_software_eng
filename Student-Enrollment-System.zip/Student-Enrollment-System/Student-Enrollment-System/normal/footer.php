<center>
<hr>

		<footer>
           <p>All Rights Reserved  </p>
        <footer>
</center>