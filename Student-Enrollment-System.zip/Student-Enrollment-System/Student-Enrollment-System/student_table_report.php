	<?php include('dbcon.php'); ?>

	<form action="delete_stud.php" method="post">
	<center><table cellpadding="0" cellspacing="0" border="0" class="table" id="example">
		<div class="pull-right">
	 <a href="#" onclick="window.print()" class="btn btn-info"><i class="icon-print icon-large"></i> Print List</a> 
	
	</div>
	<br><br>
		<thead>
		<tr>
					<th>Full Name</th>
					<th>Gender</th>
					<th>Class</th>
					<th>Class Fee</th>
					<th>Status</th>
					<th>Transport Route</th>
					<th>Phone Number</th>
		</tr>
		</thead>
		<tbody>
		<?php
		$query = mysqli_query($connection,"select * from students ")or die(mysqli_error());
		while($row = mysqli_fetch_array($query)){
			
		$myclass=$row['class'];	
		$id = $row['student_id'];
		
		
		$query2=mysqli_query($connection,"select * from class where class_name='$myclass' ")or die(mysqli_error());
		while($row2 = mysqli_fetch_array($query2)){
		$class_fee =$row2['fee'];
		}	
		?>
		<tr>
		<td><?php echo $row['firstname'].' '.$row['middlename'].' '.$row['lastname'];?></td> 
		<td><?php echo $row['gender']; ?></td> 
		<td><?php echo $row['class']; ?></td> 
		<td><?php echo $class_fee; ?></td> 
		<td><?php echo $row['status']; ?></td>
		<td>
		<?php 
				$transport = $row['transport'];
				if($transport=='yes'){
					$route=$row['route'];
				}else
				if($transport=='no'){
					$route='no transport';
				}
		
		?>
		<?php echo $route; ?></td>
		</td>
		<td><?php echo $row['tel']; ?></td>
		</tr>
	<?php } ?>    
	
		</tbody>
	</table></center>
	</form>